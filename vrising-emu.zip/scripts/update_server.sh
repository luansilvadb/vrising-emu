#!/bin/bash
# Helper script to manually update
/start.sh
